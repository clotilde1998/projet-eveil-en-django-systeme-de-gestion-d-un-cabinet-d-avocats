from django.apps import AppConfig


class AvocatsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'avocatsApp'
